
var Estudiantes= {

	'estudiantes': [
		{
			'código': '001',
			'nombre': 'David Cuellar',
			'Nota': 3.8
		},
		{
			'código': '002',
			'nombre': 'Daniel Rozo',
			'Nota': 2.4
		},
		{
			'código': '003',
			'nombre': 'Claudia Cey',
			'Nota': 4.4
		},
		{
			'código': '004',
			'nombre': 'Ammy Cely',
			'Nota': 4.7
		},
		{
			'código': '005',
			'nombre': 'Alejandra Cely',
			'Nota': 4.7
		},
		{
			'código': '006',
			'nombre': 'Maria Jose',
			'Nota': 2.9
		},
		{
			'código': '007',
			'nombre': 'Vanessa Peralta',
			'Nota': 4.4
		},
		{
			'código': '008',
			'nombre': 'Diego Maldonado',
			'Nota': 1.5
		},
		{
			'código': '009',
			'nombre': 'Sandra Cala',
			'Nota': 1.5
		},
		{
			'código': '010',
			'nombre': 'Andres lopez',
			'Nota': 1.7
		}
	]
}


function mostrarNotas() {

	var resultadoNotas='Codigo       Nombre        Nota'+'<br>';
	resultadoNotas += recorrerJson(Estudiantes, 'Mostar Notas');
	document.getElementById('resultados').innerHTML = resultadoNotas;

}

function calcularNotaPromedio(){
	document.getElementById('resultados').innerHTML = "El promedio de las notas de los estudiantes es: "+recorrerJson(Estudiantes,'Promedio Notas');
}

function estudianteNotaMayor(){
	
	document.getElementById('resultados').innerHTML = "Los datos del(os) estudiante(s) con Mayor Nota: <br>"+buscarEstudiantes(recorrerJson(Estudiantes,'Nota Mayor'));
}

function estudianteNotaMenor(){
	
	document.getElementById('resultados').innerHTML = "Los datos del(os) estudiante(s) con Menor Nota: <br>"+buscarEstudiantes(recorrerJson(Estudiantes,'Nota Menor'));
}

function recorrerJson(jsonNotas, proceso){

	var salida='';
	var arrayNotas=new Array(jsonNotas.estudiantes.length);

	for (var i = 0; i < jsonNotas.estudiantes.length; i++) {

		if (proceso == 'Mostar Notas') {
			
			salida+=jsonNotas.estudiantes[i]['código']+'       '+jsonNotas.estudiantes[i]['nombre']+'       '+jsonNotas.estudiantes[i]['Nota']+'<br>';
		
		} else if (proceso == 'Nota Mayor'||proceso == 'Nota Menor'||proceso == 'Promedio Notas'){
			
			arrayNotas[i]=jsonNotas.estudiantes[i]['Nota'];

		} 
		else {
			alert('Es necesario validar el procedimiento');
		}
	}

	arrayNotas=arrayNotas.sort();

	if (proceso == 'Nota Mayor') {

		salida= arrayNotas[jsonNotas.estudiantes.length-1];

	} 
	if (proceso == 'Nota Menor') {

		salida= arrayNotas[0];

	}  
	if (proceso == 'Promedio Notas') {

		var suma=0;

		for (var i = 0; i < arrayNotas.length; i++) {
			suma+=arrayNotas[i];
		}

		salida= suma/(jsonNotas.estudiantes.length+1);

	} 

	return salida;
}

function buscarEstudiantes(Nota){

	var datosEstudiante = "";

	for (var i = 0; i < Estudiantes.estudiantes.length; i++) {

		if(Estudiantes.estudiantes[i]['Nota']==Nota)

			datosEstudiante+=' - '+Estudiantes.estudiantes[i]['código']+'       '+Estudiantes.estudiantes[i]['nombre']+'       '+Estudiantes.estudiantes[i]['Nota']+'<br>';
		
		
	}

	return datosEstudiante
}